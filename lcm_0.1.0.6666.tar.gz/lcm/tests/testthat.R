library(testthat)
library(lcm)

test_check("lcm")
